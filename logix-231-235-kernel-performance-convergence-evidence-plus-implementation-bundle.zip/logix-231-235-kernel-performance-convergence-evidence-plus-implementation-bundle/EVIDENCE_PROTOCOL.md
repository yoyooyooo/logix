# Evidence Protocol — Logix 231–235 Kernel Performance Convergence

## Evidence Hierarchy

1. Structural sentinel / invariant proof.
2. Focused local unit or contract tests.
3. Same-commit A/B or controlled internal comparison.
4. Comparable before/after evidence under default or soak profile.
5. Broad/soak/CI/browser validation.

Layer 1–2 can prove classifier behavior. Layer 4–5 is required for hard performance claims.

## Required Profile Rules

| Profile | Interpretation |
|---|---|
| `quick`, `smoke`, `adversarial-quick` | Diagnostic clue only. |
| `default`, `soak`, `adversarial-default`, `adversarial-soak` | Eligible for hard interpretation only if all hard gates pass. |

## Required Suites

The final convergence manifest must include passing status for:

```text
adversarial.matrix.requiredHotPaths
negativeBoundaries.dirtyPattern
converge.txnCommit
form.listScopeCheck
externalStore.ingest.tickNotify
runtimeStore.noTearing.tickNotify
react.strictSuspenseJitter
diagnostics.overhead
txnQueue.directIdle
dispatchShell.fixedCost
examples.runtimeWitness
examples.playgroundNoiseIsolation
```

## Required Counters

All required counters must be present and zero unless maintainer authority explicitly accepts a migration/blocker:

```text
dirtyPlan.unknownWrite
dirtyPlan.missingRegistry
dirtyPlan.dirtyAll
dirtyPlan.nonFieldAuthority
dirtyPlan.legacyDirtyInput
source.fullFallback
source.rowFullScan
source.keyEval.unrelatedMutation
selector.evaluateAll
selector.dirtyAllFallback
selector.nonFieldAuthorityFallback
txnQueue.directIdleQueueWaitNonZero
txnQueue.directIdleBackpressureNonZero
dispatch.noTopicFanoutAlloc
runtimeStore.runSyncFallbackAfterBoot
runtimeStore.retainedTopicLeak
diagnosticsOff.payloadCount
listEvidence.stringNormalizeHotPath
examples.kernelPlaygroundCostMixed
examples.publicResidueViolation
```

## Matrix Rules

Hard adversarial matrix claims require:

- `matrixId=logix.adversarial.runtime.v1` or an explicitly accepted successor;
- artifact-provided `matrixHash`;
- `matrixHashSource=artifact` in the report;
- `comparable=true`;
- all required hot paths present;
- no blockers, no missing evidence, no unaccepted migration.

If `matrixHashSource=computed-fallback`, the report is diagnostic only.

## Risk / Cost Migration Rules

Final convergence manifests must include:

```text
migration.migratedCost
migration.migratedRisk
migration.acceptedByAuthority?   # only when non-zero migration is explicitly accepted
migration.notes?                 # required when acceptedByAuthority=true
```

Unaccepted migrated cost or risk blocks hard claims.

## Invalid / Insufficient Evidence

- Quick/smoke-only evidence.
- Missing suites or missing counters.
- Counters present but non-zero.
- `comparable=false` or missing comparability.
- Missing artifact `matrixHash`.
- Performance improvement with unaccepted migrated cost/risk.
- Browser/playground product costs mixed into kernel runtime evidence.
