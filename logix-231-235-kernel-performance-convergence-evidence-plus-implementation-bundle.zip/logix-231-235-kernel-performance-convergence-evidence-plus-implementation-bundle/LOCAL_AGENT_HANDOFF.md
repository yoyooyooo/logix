# Local Agent Handoff — Logix 231–235 Kernel Performance Convergence Evidence Bundle

## 1. Objective

Apply and validate the cloud-owned implementation patch for specs 231–235. The patch implements classifier/evidence-gate code, tests, speckit handoff notes, and perf README updates. The local agent owns apply, focused validation, local CI/perf/browser evidence collection, and minimal compile/import fixups only.

## 2. Delivery Mode

```text
mixed:
- cloud-owned implementation patch bundle
- performance / hot-path evidence gate bundle
- speckit/handoff update bundle
```

## 3. Goal Contract

```text
Goal:
- Implement stable adversarial matrix IDs/hashes and required hot-path coverage.
- Gate P0/P1/P2 fallback/fixed-cost/example evidence through classifiers.
- Fix the final convergence gate syntax blocker.
- Require risk/cost migration evidence before hard claims.
- Update specs/231-235 handoff and perf README files.

Required semantic invariants:
- No public API or export expansion.
- No benchmark-only production semantic changes.
- Missing evidence is not pass.
- Quick/smoke evidence is clue-only.
- Unaccepted migrated cost/risk blocks hard claims.
- Playground/editor product cost cannot support kernel runtime claims unless isolated.

Non-goals:
- Do not implement broad runtime optimizations from scratch.
- Do not redesign the perf pipeline.
- Do not weaken tests, suites, or gates.
- Do not edit packed XML/Repomix snapshots.

Stop conditions:
- Patch requires semantic rewrite to apply.
- Focused tests fail after minimal local fixups.
- Required counters/suites are absent but a hard claim is requested.
- Continuing requires public API expansion or broad runtime redesign.
```

## 4. Authority and Anchor

```text
Expected repo state: latest repo corresponding to uploaded source/docs/specs snapshots.
Base branch or commit: unknown in cloud; record locally with git rev-parse HEAD.
Authority docs / contracts / tests:
- specs/231-adversarial-performance-matrix/**
- specs/232-p0-kernel-precision-fallback-closure/**
- specs/233-p1-kernel-fixed-cost-and-diagnostics-closure/**
- specs/234-p2-examples-playground-perf-isolation/**
- specs/235-kernel-performance-convergence-final-gate/**
- docs/next/kernel-performance-evidence-lock.md
- docs/next/kernel-performance-convergence-p0p1p2.md
- docs/next/adversarial-performance-matrix.md
- packages/logix-perf-evidence/scripts/*.ts
```

## 5. Scope

| Path / subsystem | Allowed change | Why |
|---|---|---|
| `packages/logix-perf-evidence/scripts/**` | Apply patch and minimal compile/import fixups | Classifier/evidence implementation. |
| `specs/231-235/**` | Apply handoff/perf README notes | Speckit local execution guidance. |
| local evidence dirs under `specs/231-235/**/perf/` | Add real local artifacts only | Evidence collection. |

## 6. Non-goals

| Path / subsystem | Forbidden change | Why |
|---|---|---|
| public package roots/exports | Any new public API | Specs require no public surface expansion. |
| runtime hot paths | Broad redesign or missing optimization bodies | Not authorized by this patch. |
| tests/gates | Weakening expectations to pass | Would invalidate evidence. |
| XML snapshots | Any edits | Snapshots are read-only context. |

## 7. Files Changed or Expected

See `PATCH_MANIFEST.md`.

## 8. Implementation Coverage

See `IMPLEMENTATION_COVERAGE.md`. This is evidence-plus-implementation. Acceptance is local-evidence-gated.

## 9. Execution Order

```text
1. Record git status and HEAD.
2. Read this handoff and PATCH_MANIFEST.md.
3. Inspect the patch.
4. Run git apply --check.
5. Apply the patch.
6. Run focused validation.
7. Run typecheck/package checks if available.
8. Collect local default/soak artifacts.
9. Run final convergence classifier.
10. Record blockers, missing evidence, migration state, and allowed/forbidden claims.
```

## 10. Apply Procedure

```bash
git status --short
git rev-parse HEAD

git apply --check patches/0001-231-235-kernel-performance-convergence-evidence-gates.patch
git apply patches/0001-231-235-kernel-performance-convergence-evidence-gates.patch
```

## 11. Validation Procedure

```bash
pnpm -C packages/logix-perf-evidence test scripts/lib/adversarial-cell-id.test.ts
pnpm -C packages/logix-perf-evidence test scripts/ci.adversarial-matrix-report.test.ts
pnpm -C packages/logix-perf-evidence test scripts/ci.kernel-performance-evidence-lock.test.ts
pnpm -C packages/logix-perf-evidence test scripts/ci.kernel-performance-convergence-stage-gate.test.ts
```

Expected: PASS.

## 12. Evidence Interpretation

Hard success claim requires:

```text
profile: default/soak/adversarial-default/adversarial-soak
comparable: true
artifact matrixHash present
regressions: 0
budgetExceeded: 0
timeouts: 0
stabilityWarnings: 0
missingSuites: 0
all required suites: pass
all required counters: present and zero
migration.migratedCost: 0 unless acceptedByAuthority=true
migration.migratedRisk: 0 unless acceptedByAuthority=true
```

Local diagnostic only:

```text
quick/smoke/adversarial-quick profile
computed-fallback matrix hash
same-commit A/B without before/after comparable artifacts
```

Invalid / insufficient evidence:

```text
missing suites, missing counters, non-zero counters, incomparable diff, missing matrixHash, unaccepted migrated cost/risk
```

## 13. Risk / Cost Migration Watch

Check whether lower total cost moved to selector, source, RuntimeStore notify, externalStore snapshot, React render, diagnostics, allocations, example/product cost, or operational complexity. Classify final result as `success`, `success_with_limited_evidence`, `provisional`, `migrated_risk`, `migrated_cost`, `blocked`, or `deferred`.

## 14. Allowed Local Completion Work

- Patch context adjustment without semantic change.
- Import path correction caused by patch application.
- Formatting.
- Small compile/type fixes directly caused by this patch.
- Generated/evidence artifact refresh.
- Report updates.

## 15. Forbidden Reinterpretation

The local agent must not expand scope, redesign architecture, add public APIs, weaken tests/gates, bypass runtime ownership, create second truth sources, or implement large missing optimization bodies.

## 16. Stop Conditions

Stop and report if any condition in section 3 or 15 is hit, or if local validation requires out-of-scope features.

## 17. Expected Result

The delivery is locally accepted only when apply succeeds, focused tests pass, expected files exist, evidence artifacts are produced where required, risk/cost migration is classified, and final claims are limited to evidence.

## 18. Cloud LLM Validation Limitations

Cloud did not run pnpm install, package tests, browser tests, perf collect, perf diff, default/soak profile, DB, provider, or local CI. Cloud apply-check succeeded on a reconstructed snapshot. TypeScript dry-check was limited by missing Node/Vitest type dependencies in the extracted snapshot.

## 19. Report Template

```text
delivery_name: logix-231-235-kernel-performance-convergence-evidence-plus-implementation
delivery_mode: evidence-plus-implementation patch bundle
repo_head_before:
repo_head_after:
dirty_worktree_before:
dirty_worktree_after:
apply_result:
patches_applied:
implementation_coverage_matches_manifest:
commands_run:
passed_checks:
failed_checks:
expected_failures:
local_fixes:
files_changed_after_apply:
evidence_artifacts:
risk_or_cost_migration:
stop_conditions_hit:
scope_deviations:
unresolved_questions:
allowed_claims:
forbidden_claims:
recommended_next_anchor:
```
