# Patch Manifest — Logix 231–235 Kernel Performance Convergence Evidence Bundle

## Patch Order

| Order | Patch | Type | Purpose | Must apply before |
|---:|---|---|---|---|
| 1 | `patches/0001-231-235-kernel-performance-convergence-evidence-gates.patch` | implementation + tests + speckit docs | Adds classifier/gate implementation for specs 231–235 and updates handoff/perf docs | n/a |

## Changed Paths

| Path | Patch | Change type | Purpose |
|---|---|---|---|
| `packages/logix-perf-evidence/scripts/lib/adversarial-axis.ts` | 0001 | create | Deterministic JSON-safe adversarial axis normalization. |
| `packages/logix-perf-evidence/scripts/lib/adversarial-cell-id.ts` | 0001 | create | Stable adversarial cell ID and matrix hash helpers. |
| `packages/logix-perf-evidence/scripts/lib/adversarial-cell-id.test.ts` | 0001 | create | Unit tests for cell ID and matrix hash determinism. |
| `packages/logix-perf-evidence/scripts/ci.adversarial-matrix-report.ts` | 0001 | modify | Expanded required hot paths, deterministic cell IDs, artifact matrix hash gating, migration detection. |
| `packages/logix-perf-evidence/scripts/ci.adversarial-matrix-report.test.ts` | 0001 | modify | Tests for P0/P1/P2 suite aliases and missing artifact matrix hash. |
| `packages/logix-perf-evidence/scripts/ci.kernel-performance-evidence-lock.ts` | 0001 | modify | Adds P0/P1/P2 required suites/counters and output-directory creation. |
| `packages/logix-perf-evidence/scripts/ci.kernel-performance-evidence-lock.test.ts` | 0001 | modify | Adjusts missing-suite expectation for expanded required suites. |
| `packages/logix-perf-evidence/scripts/ci.kernel-performance-convergence-stage-gate.ts` | 0001 | modify | Fixes syntax blocker, adds migration gate, supports adversarial default/soak hard profiles. |
| `packages/logix-perf-evidence/scripts/ci.kernel-performance-convergence-stage-gate.test.ts` | 0001 | modify | Tests migration blocking, missing migration evidence, and report rendering. |
| `specs/231-adversarial-performance-matrix/handoff.md` | 0001 | modify | Speckit handoff notes for implemented cloud patch and local validation. |
| `specs/232-p0-kernel-precision-fallback-closure/handoff.md` | 0001 | modify | Speckit handoff notes for P0 gate coverage. |
| `specs/233-p1-kernel-fixed-cost-and-diagnostics-closure/handoff.md` | 0001 | modify | Speckit handoff notes for P1 gate coverage. |
| `specs/234-p2-examples-playground-perf-isolation/handoff.md` | 0001 | modify | Speckit handoff notes for P2 example/playground isolation evidence. |
| `specs/235-kernel-performance-convergence-final-gate/handoff.md` | 0001 | modify | Speckit handoff notes for final gate and migration gate. |
| `specs/231-adversarial-performance-matrix/perf/README.md` through `specs/235-kernel-performance-convergence-final-gate/perf/README.md` | 0001 | modify | Adds local evidence manifest requirements and cloud-owned evidence notes. |

## Public Surface

No public API, package export, root export, schema, DB migration, config surface, or CLI command is added. Existing CLI scripts are tightened.

## Apply Rules

```bash
git status --short
git rev-parse HEAD

git apply --check patches/0001-231-235-kernel-performance-convergence-evidence-gates.patch
git apply patches/0001-231-235-kernel-performance-convergence-evidence-gates.patch
```

## Conflict Policy

The local agent may resolve patch context mismatch without changing semantics. Stop and report if applying requires a semantic rewrite, public API expansion, runtime architecture redesign, or broad unrelated refactor.
