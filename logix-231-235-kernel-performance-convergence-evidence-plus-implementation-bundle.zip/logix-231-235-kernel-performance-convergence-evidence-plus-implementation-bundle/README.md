# Logix 231–235 Kernel Performance Convergence Evidence Bundle

## Purpose

This bundle delivers a cloud-owned implementation patch for `specs/231` through `specs/235` using the latest uploaded `source.xml`, `docs.xml`, and `specs.xml` snapshots.

## Delivery Type

Evidence-plus-implementation patch bundle. It is not a full performance-success proof, because cloud execution could not run pnpm, CI, browser perf, DB, or default/soak benchmark collection.

## Contents

- `patches/0001-231-235-kernel-performance-convergence-evidence-gates.patch`
- User/maintainer docs: this README plus `PATCH_MANIFEST.md`, `IMPLEMENTATION_COVERAGE.md`, `VERIFY.md`, `EVIDENCE_PROTOCOL.md`, `RISK_LEDGER.md`
- Local execution handoff: `LOCAL_AGENT_HANDOFF.md`
- Cloud validation notes: `CLOUD_VALIDATION.md`
- `speckit/231-235-speckit-handoff.md`
- `SHA256SUMS`

## Implementation Summary

The patch implements classifier and evidence-gate work for the 231–235 stage set:

- adds deterministic adversarial matrix axis normalization, cell IDs, and matrix hashes;
- expands adversarial required hot paths to include P0/P1/P2 convergence lanes;
- enforces artifact `matrixHash` presence for hard claims;
- extends evidence-lock and final convergence gates to require P0/P1/P2 suites and counters;
- fixes the final convergence gate syntax blocker around `DEFAULT_CLOUD_LIMITATIONS`;
- adds explicit risk/cost migration gating to the final convergence gate;
- updates speckit handoffs and perf README files with cloud-owned patch notes and local-evidence rules.

## Where to Apply

Apply from the repository root that corresponds to the uploaded snapshots.

## First File for Local Agent

Read `LOCAL_AGENT_HANDOFF.md` before applying this delivery.

## Apply Summary

```bash
git apply --check patches/0001-231-235-kernel-performance-convergence-evidence-gates.patch
git apply patches/0001-231-235-kernel-performance-convergence-evidence-gates.patch
```

## Validation Summary

Cloud-side `git apply --check` succeeded against a reconstructed repository snapshot. A local `tsc --noEmit` syntax pass was attempted against the patched scripts, but the extracted snapshot lacks package metadata and `@types/node`, so it stopped at missing Node type declarations. No pnpm, Vitest, browser, CI, or perf benchmark was run in cloud.

## Non-goals

- No public API, root export, submodule, or authoring noun is added.
- No runtime performance success is claimed.
- No quick/smoke evidence is treated as hard evidence.
- No packed XML/Repomix snapshot is edited.

## Known Cloud LLM Limitations

The patch is implementation-bearing, but acceptance remains local-evidence-gated. Hard claims require local default/soak comparable evidence, passing focused tests, zero required counters, no missing suites, and no unaccepted migrated cost/risk.
