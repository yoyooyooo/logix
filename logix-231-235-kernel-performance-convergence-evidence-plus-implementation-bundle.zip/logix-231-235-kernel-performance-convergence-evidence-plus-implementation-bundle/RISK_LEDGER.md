# Risk Ledger — Logix 231–235 Kernel Performance Convergence Evidence Bundle

| Risk | Area | Detection | Status | Required local evidence | Stop condition |
|---|---|---|---|---|---|
| Patch applies but classifier tests fail | correctness | focused Vitest tests | open | four focused perf-evidence test commands | Stop; do not collect or classify perf claims. |
| Matrix hash missing from artifacts | evidence integrity | `matrixHashSource=computed-fallback` and missingEvidence entry | open | real collect/diff artifact with artifact matrix hash | Stop hard claim; diagnostic only. |
| P0 fallback counter absent or non-zero | precision fallback | final convergence gate counters | open | default/soak manifest with P0 counters present and zero | Stop; classify `incomplete` or `blocked`. |
| P1 diagnostics-off path hides payload construction instead of measuring it | diagnostics / observability | diagnostics-off payload counter and focused sentinel tests | open | local diagnostics-off sentinels | Stop if counter absent/non-zero or sentinel weakened. |
| P2 examples mix playground/editor cost into kernel claim | evidence authority | examples/playground suites and counters | open | isolated runtime example evidence and product-only playground evidence | Stop hard kernel claim if mixed cost counter non-zero. |
| Total latency improves but cost moves into selector/store/source/React | migrated cost | adversarial matrix migration phases and final migration gate | open | migration report with phase deltas | Stop unless explicitly accepted by maintainer authority. |
| Local agent implements missing runtime optimization bodies | scope / architecture | worktree diff review | open | patch-only/local-fix audit | Stop unless separately authorized. |

## Risk / Cost Migration

| Improved area | Possible migrated area | Evidence required | Classification |
|---|---|---|---|
| field-kernel dirty work | selector route / RuntimeStore notify | phase deltas and fallback counters | `migrated_cost` if regressed without acceptance |
| dispatch fixed cost | diagnostics payload or topic lifecycle | diagnostics-off and retained-topic counters | `migrated_risk` if evidence is missing |
| runtime examples | playground/editor product cost | P2 suite and mixed-cost counter | `blocked` if mixed |
| report gate completeness | false hard success | missingEvidence and blockers | `incomplete` / `blocked` |
