# Verification — Logix 231–235 Kernel Performance Convergence Evidence Bundle

## Preflight

```bash
git status --short
git rev-parse HEAD
```

Record unrelated dirty worktree changes before applying. Do not reset, clean, restore, stash, or overwrite unrelated work.

## Apply

```bash
git apply --check patches/0001-231-235-kernel-performance-convergence-evidence-gates.patch
git apply patches/0001-231-235-kernel-performance-convergence-evidence-gates.patch
```

Expected: both commands complete without conflict.

## Focused Validation

```bash
pnpm -C packages/logix-perf-evidence test scripts/lib/adversarial-cell-id.test.ts
pnpm -C packages/logix-perf-evidence test scripts/ci.adversarial-matrix-report.test.ts
pnpm -C packages/logix-perf-evidence test scripts/ci.kernel-performance-evidence-lock.test.ts
pnpm -C packages/logix-perf-evidence test scripts/ci.kernel-performance-convergence-stage-gate.test.ts
```

Expected: PASS.

## Typecheck / Build

Run the repository-standard checks if available:

```bash
pnpm typecheck
pnpm -C packages/logix-perf-evidence test
```

Expected: PASS or documented pre-existing unrelated failure.

## Evidence Artifacts

Local default/soak evidence must be collected after applying the patch. Expected local artifact locations:

```text
specs/231-adversarial-performance-matrix/perf/reports/*.json
specs/232-p0-kernel-precision-fallback-closure/perf/reports/*.json
specs/233-p1-kernel-fixed-cost-and-diagnostics-closure/perf/reports/*.json
specs/234-p2-examples-playground-perf-isolation/perf/reports/*.json
specs/235-kernel-performance-convergence-final-gate/perf/reports/*.json
```

## Final Gate Example

```bash
pnpm exec tsx packages/logix-perf-evidence/scripts/ci.kernel-performance-convergence-stage-gate.ts \
  --manifest specs/231-adversarial-performance-matrix/perf/convergence.manifest.default.json \
  --out specs/235-kernel-performance-convergence-final-gate/perf/reports/convergence.default.md \
  --json-out specs/235-kernel-performance-convergence-final-gate/perf/reports/convergence.default.json
```

Expected for hard success: `classification=complete`, `claimStrength=hard`, zero blockers, zero missing evidence, default/soak profile, comparable evidence, all required suites pass, all required counters are zero, and `migration.migratedCost=0`, `migration.migratedRisk=0` unless maintainer-accepted.

## Cloud Validation Actually Performed

Cloud reconstructed the uploaded repository snapshot and ran:

```bash
git apply --check patches/0001-231-235-kernel-performance-convergence-evidence-gates.patch
```

Result: PASS.

Cloud also attempted a TypeScript syntax/type dry-check with the system `tsc`, but the extracted snapshot lacks package metadata and Node/Vitest type dependencies. The command stopped at missing `node:*` and `vitest` type declarations. No successful typecheck is claimed.

## Failure Interpretation

- Patch context conflict: local agent may make minimal context-only adjustment.
- Missing Node/Vitest types in the extracted snapshot: not a repo failure by itself; rerun in the real repository with dependencies installed.
- Any failed focused test: stop and report.
- Any missing/non-zero required counter: classify as `incomplete` or `blocked`; do not claim convergence.
- Quick/smoke-only evidence: clue only; do not claim release-safe performance.
