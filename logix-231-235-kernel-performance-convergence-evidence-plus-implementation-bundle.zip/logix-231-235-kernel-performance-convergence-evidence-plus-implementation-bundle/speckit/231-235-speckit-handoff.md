# Speckit Handoff — specs/231–235

## Target Specs

- `specs/231-adversarial-performance-matrix`
- `specs/232-p0-kernel-precision-fallback-closure`
- `specs/233-p1-kernel-fixed-cost-and-diagnostics-closure`
- `specs/234-p2-examples-playground-perf-isolation`
- `specs/235-kernel-performance-convergence-final-gate`

## Cloud-Owned Implementation Applied by Patch

- 231: classifier-level adversarial matrix determinism, expanded hot paths, matrixHash gating, and migration classification.
- 232: P0 fallback counters enforced by evidence-lock/final-gate classifiers.
- 233: P1 fixed-cost/diagnostics/listEvidence counters enforced by classifiers.
- 234: P2 examples/playground isolation suites and counters enforced by classifiers.
- 235: final convergence gate syntax fix and migration gate.

## Speckit Artifact Updates

The patch updates each stage `handoff.md` and `perf/README.md` with cloud-owned delivery notes and local evidence requirements. These are control artifacts; they do not replace local evidence.

## Local Completion Boundary

Local agent should not re-design specs 231–235. It should apply the patch, run the focused commands, collect real local evidence, and record the result in the stage handoffs/perf reports.
